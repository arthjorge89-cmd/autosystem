import os
import tempfile
import unittest
from datetime import date, timedelta
from werkzeug.security import generate_password_hash

import app as automecanica


class AutoMecanicaTestCase(unittest.TestCase):
    def setUp(self):
        self.db_fd, self.db_path = tempfile.mkstemp(suffix=".db")
        automecanica.DB_PATH = self.db_path
        automecanica.app.config["TESTING"] = True
        automecanica.init_db()
        self.client = automecanica.app.test_client()

    def tearDown(self):
        os.close(self.db_fd)
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    # ==================== TESTES UNITÁRIOS ====================

    def test_unit_password_hashing(self):
        hashed = generate_password_hash("senha_secreta")
        self.assertNotEqual(hashed, "senha_secreta")
        self.assertTrue(automecanica.check_password_hash(hashed, "senha_secreta"))
        self.assertFalse(automecanica.check_password_hash(hashed, "errada"))

    def test_unit_stock_deduction_and_refund(self):
        with automecanica.get_db() as conn:
            # Pastilha de freio (id=2) inicia com qtd=3, minimo=4
            os_pending = {
                "id": 99,
                "status": "Pendente",
                "estoqueBaixado": False,
                "itens": [{"pecaId": 2, "peca": "Pastilha de freio (jogo)", "qtd": 2}],
            }
            os_running = {**os_pending, "status": "Em Andamento"}

            alerts = automecanica.sync_stock(conn, os_pending, os_running)
            qtd_after = conn.execute("SELECT qtd FROM estoque WHERE id=2").fetchone()["qtd"]
            self.assertEqual(qtd_after, 1)
            self.assertIn("Pastilha de freio (jogo)", alerts)

            # Estorno ao cancelar/voltar para Pendente
            os_running["estoqueBaixado"] = True
            automecanica.sync_stock(conn, os_running, os_pending)
            qtd_refunded = conn.execute("SELECT qtd FROM estoque WHERE id=2").fetchone()["qtd"]
            self.assertEqual(qtd_refunded, 3)

    def test_unit_slots_weekday_vs_sunday(self):
        # Encontra o próximo domingo
        d = date.today()
        while d.weekday() != 6:
            d += timedelta(days=1)
        with automecanica.get_db() as conn:
            sunday_slots = automecanica.get_slots_for_date(conn, d.isoformat())
            self.assertEqual(sunday_slots, [])

    # ==================== TESTES DE INTEGRAÇÃO ====================

    def test_integration_client_security_and_budget_approval(self):
        # 1. Sem login não consulta OS
        res_unauth = self.client.get("/api/os/consulta/8")
        self.assertEqual(res_unauth.status_code, 401)

        # 2. Carlos (id=1) faz login e tenta acessar/aprovar OS #8 da Mariana (id=2) -> 403 Forbidden
        self.client.post("/api/cliente/login", json={"login": "carlos@email.com", "senha": "1234"})
        res_forbidden_view = self.client.get("/api/os/consulta/8")
        self.assertEqual(res_forbidden_view.status_code, 403)

        res_forbidden_approve = self.client.post("/api/cliente/os/8/aprovar")
        self.assertEqual(res_forbidden_approve.status_code, 403)

        # 3. Mariana (id=2, proprietária da OS #8) faz login e aprova seu orçamento -> 200 OK
        self.client.post("/api/cliente/login", json={"login": "mariana@email.com", "senha": "1234"})
        res_ok = self.client.post("/api/cliente/os/8/aprovar")
        self.assertEqual(res_ok.status_code, 200)
        body = res_ok.get_json()
        self.assertEqual(body["record"]["status"], "Em Andamento")
        self.assertTrue(body["record"]["estoqueBaixado"])

    def test_integration_scheduling_slot_conflict_and_home_service(self):
        # Próxima segunda-feira
        d = date.today() + timedelta(days=1)
        while d.weekday() != 0:
            d += timedelta(days=1)
        target = d.isoformat()

        payload = {
            "nome": "Lucas Andrade",
            "telefone": "(81) 98888-7777",
            "veiculo": "Toyota Corolla 2020",
            "servico": "Troca de óleo",
            "modalidade": "Serviço em domicílio",
            "endereco": "Rua da Aurora, 500 - Boa Vista",
            "data": target,
            "horario": "14:00",
        }
        r1 = self.client.post("/api/agenda", json=payload)
        self.assertEqual(r1.status_code, 201)

        # Tentar agendar no mesmo dia e horário deve retornar 409 Conflict
        r2 = self.client.post("/api/agenda", json=payload)
        self.assertEqual(r2.status_code, 409)

    def test_integration_staff_rbac_permissions(self):
        # Mecânico pode listar/editar OS, mas não pode excluir clientes (403)
        login_mec = self.client.post("/api/admin/login", json={"username": "mecanico", "senha": "1234"})
        self.assertEqual(login_mec.status_code, 200)

        del_attempt = self.client.delete("/api/clientes/1")
        self.assertEqual(del_attempt.status_code, 403)

        # Gerente tem permissão administrativa completa
        login_mgr = self.client.post("/api/admin/login", json={"username": "admin", "senha": "1234"})
        self.assertEqual(login_mgr.status_code, 200)
        cfg = self.client.get("/api/config")
        self.assertEqual(cfg.status_code, 200)


if __name__ == "__main__":
    unittest.main(verbosity=2)