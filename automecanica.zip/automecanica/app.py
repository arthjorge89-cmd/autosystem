import json
import os
import re
import sqlite3
import urllib.request
from datetime import date, datetime, timedelta
from functools import wraps
from flask import Flask, jsonify, render_template, request, session
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "automecanica-chave-segura-2026")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "oficina.db")
CONSUMES = ("Em Andamento", "Concluído")
HORARIOS_SEMANA = ["08:00", "09:00", "10:00", "11:00", "14:00", "15:00", "16:00", "17:00"]
HORARIOS_SABADO = ["08:00", "09:00", "10:00", "11:00"]


def only_digits(val):
    return re.sub(r"\D", "", str(val or ""))


def dia_iso(offset=0):
    return (date.today() - timedelta(days=offset)).isoformat()


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with get_db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS config (
            chave TEXT PRIMARY KEY,
            valor TEXT
        );
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            nome TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('gerente', 'mecanico')),
            senha_hash TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            telefone TEXT NOT NULL,
            email TEXT DEFAULT '',
            endereco TEXT DEFAULT '',
            senha_hash TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS veiculos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            placa TEXT NOT NULL UNIQUE,
            modelo TEXT NOT NULL,
            ano INTEGER,
            cliente_id INTEGER NOT NULL,
            FOREIGN KEY (cliente_id) REFERENCES clientes(id)
        );
        CREATE TABLE IF NOT EXISTS estoque (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            peca TEXT NOT NULL,
            qtd INTEGER NOT NULL DEFAULT 0,
            minimo INTEGER NOT NULL DEFAULT 0,
            preco_custo REAL NOT NULL DEFAULT 0,
            preco REAL NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS ordens_servico (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            num INTEGER NOT NULL UNIQUE,
            cliente_id INTEGER NOT NULL,
            veiculo_id INTEGER NOT NULL,
            km INTEGER DEFAULT 0,
            descricao TEXT NOT NULL,
            modalidade TEXT DEFAULT 'Na oficina',
            endereco_atendimento TEXT DEFAULT '',
            diagnostico_tecnico TEXT DEFAULT '',
            mao_obra REAL DEFAULT 0,
            valor REAL DEFAULT 0,
            custo_total REAL DEFAULT 0,
            pagamento TEXT DEFAULT 'Pendente',
            status TEXT DEFAULT 'Pendente',
            data TEXT NOT NULL,
            estoque_baixado INTEGER DEFAULT 0,
            aprovado_em TEXT,
            obs_cliente TEXT DEFAULT '',
            resposta_oficina TEXT DEFAULT '',
            FOREIGN KEY (cliente_id) REFERENCES clientes(id),
            FOREIGN KEY (veiculo_id) REFERENCES veiculos(id)
        );
        CREATE TABLE IF NOT EXISTS os_itens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            os_id INTEGER NOT NULL,
            peca_id INTEGER,
            peca TEXT NOT NULL,
            qtd INTEGER NOT NULL CHECK(qtd > 0),
            preco_unit REAL NOT NULL DEFAULT 0,
            custo_unit REAL DEFAULT 0,
            FOREIGN KEY (os_id) REFERENCES ordens_servico(id) ON DELETE CASCADE,
            FOREIGN KEY (peca_id) REFERENCES estoque(id)
        );
        CREATE TABLE IF NOT EXISTS agenda (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER,
            nome TEXT NOT NULL,
            telefone TEXT NOT NULL,
            veiculo TEXT NOT NULL,
            servico TEXT NOT NULL,
            modalidade TEXT DEFAULT 'Na oficina',
            endereco TEXT DEFAULT '',
            data TEXT NOT NULL,
            horario TEXT NOT NULL DEFAULT '09:00',
            status TEXT DEFAULT 'Pendente',
            FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL
        );
        """)
        conn.execute("INSERT OR IGNORE INTO config(chave, valor) VALUES('webhookUrl', '')")

        if conn.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0] == 0:
            conn.executemany(
                "INSERT INTO usuarios(username, nome, role, senha_hash) VALUES(?,?,?,?)",
                [
                    ("admin", "Gerente AutoMecânica", "gerente", generate_password_hash("1234")),
                    ("mecanico", "Mecânico Técnico", "mecanico", generate_password_hash("1234")),
                ],
            )

        if conn.execute("SELECT COUNT(*) FROM clientes").fetchone()[0] == 0:
            senha_padrao = generate_password_hash("1234")
            conn.executemany(
                "INSERT INTO clientes(nome, telefone, email, endereco, senha_hash) VALUES(?,?,?,?,?)",
                [
                    ("Carlos Silva", "(81) 99111-1111", "carlos@email.com", "Rua das Flores, 45 - Piedade", senha_padrao),
                    ("Mariana Souza", "(81) 99222-2222", "mariana@email.com", "Av. Bernardo Vieira de Melo, 1200 - Piedade", senha_padrao),
                    ("Paulo Lima", "(81) 99333-3333", "paulo@email.com", "Rua São Sebastião, 88 - Prazeres", senha_padrao),
                ],
            )
            conn.executemany(
                "INSERT INTO veiculos(placa, modelo, ano, cliente_id) VALUES(?,?,?,?)",
                [
                    ("ABC1D23", "Honda Civic", 2018, 1),
                    ("QWE4R56", "Fiat Argo", 2021, 2),
                    ("JKL7M89", "VW Gol", 2015, 3),
                ],
            )
            conn.executemany(
                "INSERT INTO estoque(peca, qtd, minimo, preco_custo, preco) VALUES(?,?,?,?,?)",
                [
                    ("Filtro de óleo", 12, 5, 18, 35),
                    ("Pastilha de freio (jogo)", 3, 4, 82, 140),
                    ("Vela de ignição (jogo)", 20, 8, 48, 95),
                    ("Óleo sintético 5W30 (4L)", 9, 4, 95, 165),
                    ("Bateria 60Ah", 4, 2, 260, 420),
                ],
            )
            os_seed = [
                (1, 1, 1, 62100, "Troca de óleo e filtros", "Na oficina", "", "Troca preventiva concluída sem anomalias.", 120, 320, 113, "Pix", "Concluído", dia_iso(6), 1, f"{dia_iso(6)} 09:15", "", ""),
                (2, 2, 2, 41200, "Revisão de freios dianteiros", "Na oficina", "", "Pastilhas substituídas e disco testado.", 240, 380, 82, "Crédito", "Concluído", dia_iso(5), 1, f"{dia_iso(5)} 10:40", "", ""),
                (3, 3, 3, 94500, "Alinhamento, balanceamento e velas", "Na oficina", "", "Geometria ajustada e velas novas.", 150, 245, 48, "Débito", "Concluído", dia_iso(3), 1, None, "", ""),
                (4, 1, 1, 65800, "Substituição de bateria 60Ah", "Serviço em domicílio", "Rua das Flores, 45 - Piedade", "Atendimento em domicílio realizado; alternador carregando a 14.1V.", 60, 480, 260, "Pix", "Concluído", dia_iso(2), 1, f"{dia_iso(2)} 14:20", "", ""),
                (5, 2, 2, 43900, "Revisão de suspensão dianteira", "Na oficina", "", "Substituição de bieletas e buchas.", 720, 720, 0, "Crédito", "Concluído", dia_iso(1), 1, None, "", ""),
                (6, 3, 3, 96100, "Higienização e carga de ar-condicionado", "Na oficina", "", "Sistema sem vazamentos e gás recarregado.", 260, 260, 0, "Dinheiro", "Concluído", dia_iso(0), 1, None, "", ""),
                (7, 1, 1, 68450, "Diagnóstico eletrônico e troca de velas", "Na oficina", "", "Scanner apontou falha no cilindro 2; velas sendo substituídas.", 140, 235, 48, "Pendente", "Em Andamento", dia_iso(0), 1, f"{dia_iso(0)} 08:50", "", "Peças já separadas na bancada."),
                (8, 2, 2, 45300, "Revisão completa 45.000 km", "Busca e entrega", "Av. Bernardo Vieira de Melo, 1200 - Piedade", "Veículo coletado no endereço. Pastilhas com 2mm e óleo vencido.", 290, 630, 195, "Pendente", "Aguardando Aprovação", dia_iso(0), 0, None, "", ""),
            ]
            conn.executemany(
                """INSERT INTO ordens_servico
                   (num, cliente_id, veiculo_id, km, descricao, modalidade, endereco_atendimento,
                    diagnostico_tecnico, mao_obra, valor, custo_total, pagamento, status,
                    data, estoque_baixado, aprovado_em, obs_cliente, resposta_oficina)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                os_seed,
            )
            itens_seed = [
                (1, 1, "Filtro de óleo", 1, 35, 18),
                (1, 4, "Óleo sintético 5W30 (4L)", 1, 165, 95),
                (2, 2, "Pastilha de freio (jogo)", 1, 140, 82),
                (3, 3, "Vela de ignição (jogo)", 1, 95, 48),
                (4, 5, "Bateria 60Ah", 1, 420, 260),
                (7, 3, "Vela de ignição (jogo)", 1, 95, 48),
                (8, 1, "Filtro de óleo", 1, 35, 18),
                (8, 4, "Óleo sintético 5W30 (4L)", 1, 165, 95),
                (8, 2, "Pastilha de freio (jogo)", 1, 140, 82),
            ]
            conn.executemany(
                "INSERT INTO os_itens(os_id, peca_id, peca, qtd, preco_unit, custo_unit) VALUES(?,?,?,?,?,?)",
                itens_seed,
            )
            conn.execute(
                """INSERT INTO agenda(cliente_id, nome, telefone, veiculo, servico, modalidade, endereco, data, horario, status)
                   VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (3, "Paulo Lima", "(81) 99333-3333", "VW Gol 2015", "Troca de óleo", "Serviço em domicílio", "Rua São Sebastião, 88 - Prazeres", dia_iso(0), "10:00", "Pendente"),
            )


def error(message, status=400):
    return jsonify({"error": str(message)}), status


def require_staff(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("staff_role"):
            return error("Acesso restrito à equipe. Faça login no painel administrativo.", 401)
        return fn(*args, **kwargs)
    return wrapper


def require_manager(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if session.get("staff_role") != "gerente":
            return error("Apenas o gerente possui permissão para esta ação.", 403)
        return fn(*args, **kwargs)
    return wrapper


def require_client(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("cliente_id"):
            return error("Faça login como cliente para acessar seus veículos e orçamentos.", 401)
        return fn(*args, **kwargs)
    return wrapper


def serialize_cliente(row):
    d = dict(row)
    return {
        "id": d["id"],
        "nome": d["nome"],
        "telefone": d["telefone"],
        "email": d.get("email") or "",
        "endereco": d.get("endereco") or "",
    }


def serialize_os(conn, row):
    d = dict(row)
    itens = conn.execute("SELECT * FROM os_itens WHERE os_id=?", (d["id"],)).fetchall()
    vei = conn.execute("SELECT * FROM veiculos WHERE id=?", (d["veiculo_id"],)).fetchone()
    veiculo_label = (
        f"{vei['modelo']}{' ' + str(vei['ano']) if vei['ano'] else ''} · {vei['placa']}"
        if vei else "—"
    )
    return {
        "id": d["id"],
        "num": d["num"],
        "clienteId": d["cliente_id"],
        "veiculoId": d["veiculo_id"],
        "veiculo": veiculo_label,
        "km": d["km"],
        "descricao": d["descricao"],
        "modalidade": d.get("modalidade") or "Na oficina",
        "enderecoAtendimento": d.get("endereco_atendimento") or "",
        "diagnosticoTecnico": d.get("diagnostico_tecnico") or "",
        "maoObra": d["mao_obra"],
        "valor": d["valor"],
        "custoTotal": d["custo_total"],
        "pagamento": d["pagamento"],
        "status": d["status"],
        "data": d["data"],
        "estoqueBaixado": bool(d["estoque_baixado"]),
        "aprovadoEm": d["aprovado_em"],
        "obsCliente": d["obs_cliente"] or "",
        "respostaOficina": d.get("resposta_oficina") or "",
        "itens": [
            {
                "pecaId": x["peca_id"],
                "peca": x["peca"],
                "qtd": x["qtd"],
                "precoUnit": x["preco_unit"],
                "custoUnit": x["custo_unit"],
            }
            for x in itens
        ],
    }


def serialize_row(conn, resource, row):
    d = dict(row)
    if resource == "clientes":
        return serialize_cliente(row)
    if resource == "veiculos":
        return {
            "id": d["id"],
            "placa": d["placa"],
            "modelo": d["modelo"],
            "ano": d["ano"],
            "clienteId": d["cliente_id"],
        }
    if resource == "estoque":
        return {
            "id": d["id"],
            "peca": d["peca"],
            "qtd": d["qtd"],
            "minimo": d["minimo"],
            "precoCusto": d["preco_custo"],
            "preco": d["preco"],
        }
    if resource == "agenda":
        return {
            "id": d["id"],
            "clienteId": d.get("cliente_id"),
            "nome": d["nome"],
            "telefone": d["telefone"],
            "veiculo": d["veiculo"],
            "servico": d["servico"],
            "modalidade": d.get("modalidade") or "Na oficina",
            "endereco": d.get("endereco") or "",
            "data": d["data"],
            "horario": d.get("horario") or "09:00",
            "status": d["status"],
        }
    if resource == "os":
        return serialize_os(conn, row)
    return d


def stock_change(conn, item, direction):
    if item.get("pecaId") is not None:
        cur = conn.execute("SELECT qtd FROM estoque WHERE id=?", (item["pecaId"],)).fetchone()
        if not cur:
            raise ValueError(f"Peça de estoque {item['pecaId']} não encontrada.")
        new_qty = cur["qtd"] + direction * int(item["qtd"])
        if new_qty < 0:
            raise ValueError(f"Estoque insuficiente para {item.get('peca', 'a peça')}.")
        conn.execute("UPDATE estoque SET qtd=? WHERE id=?", (new_qty, item["pecaId"]))


def sync_stock(conn, previous, current):
    alerts = []
    if previous and previous["estoqueBaixado"]:
        for item in previous["itens"]:
            stock_change(conn, item, +1)
    consumes = current and current["status"] in CONSUMES and current["itens"]
    if consumes:
        for item in current["itens"]:
            stock_change(conn, item, -1)
            if item.get("pecaId"):
                p = conn.execute(
                    "SELECT peca, qtd, minimo FROM estoque WHERE id=?", (item["pecaId"],)
                ).fetchone()
                if p and p["qtd"] <= p["minimo"] and p["peca"] not in alerts:
                    alerts.append(p["peca"])
        conn.execute("UPDATE ordens_servico SET estoque_baixado=1 WHERE id=?", (current["id"],))
    elif current:
        conn.execute("UPDATE ordens_servico SET estoque_baixado=0 WHERE id=?", (current["id"],))
    return alerts


def get_slots_for_date(conn, target_date):
    dt = date.fromisoformat(target_date)
    weekday = dt.weekday()  # 0=Mon ... 5=Sat, 6=Sun
    if weekday == 6:
        base_slots = []
    elif weekday == 5:
        base_slots = HORARIOS_SABADO
    else:
        base_slots = HORARIOS_SEMANA

    booked_rows = conn.execute(
        "SELECT horario FROM agenda WHERE data=? AND status != 'Cancelado'",
        (target_date,),
    ).fetchall()
    booked = {r["horario"] for r in booked_rows}
    return [{"hora": h, "disponivel": h not in booked} for h in base_slots]


def send_webhook(conn, appointment):
    row = conn.execute("SELECT valor FROM config WHERE chave='webhookUrl'").fetchone()
    url = (row["valor"] if row else "").strip()
    if not url:
        return
    payload = {
        "content": "Novo agendamento no site — AutoMecânica",
        "embeds": [
            {
                "title": f"Agendamento #{appointment['id']} - {appointment['servico']}",
                "fields": [
                    {"name": "Cliente", "value": appointment["nome"]},
                    {"name": "Telefone", "value": appointment["telefone"]},
                    {"name": "Veículo", "value": appointment["veiculo"]},
                    {"name": "Modalidade", "value": appointment.get("modalidade", "Na oficina")},
                    {"name": "Data / Hora", "value": f"{appointment['data']} às {appointment.get('horario', '09:00')}"},
                ],
            }
        ],
    }
    try:
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=5).close()
    except Exception as exc:
        app.logger.warning("Falha ao enviar webhook: %s", exc)


# ==================== ROTAS PÚBLICAS & ÁREA DO CLIENTE ====================

@app.route("/")
def index():
    return render_template("index.html")


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "database": os.path.basename(DB_PATH)})


@app.get("/api/public/hero")
def public_hero():
    with get_db() as conn:
        row = conn.execute(
            """SELECT o.num, o.status, o.descricao, v.modelo, v.ano
               FROM ordens_servico o
               JOIN veiculos v ON v.id = o.veiculo_id
               WHERE o.status IN ('Em Andamento', 'Aguardando Aprovação')
               ORDER BY o.id DESC LIMIT 1"""
        ).fetchone()
        if not row:
            return jsonify(None)
        return jsonify({
            "num": row["num"],
            "status": row["status"],
            "descricao": row["descricao"],
            "veiculo": f"{row['modelo']}{' ' + str(row['ano']) if row['ano'] else ''}",
        })


@app.get("/api/agenda/horarios")
def api_horarios():
    target_date = (request.args.get("data") or "").strip()
    if not target_date:
        return error("Informe a data no formato YYYY-MM-DD.")
    try:
        slots = get_slots_for_date(get_db(), target_date)
    except ValueError:
        return error("Data inválida.")
    return jsonify({"data": target_date, "horarios": slots})


@app.post("/api/cliente/register")
def cliente_register():
    body = request.get_json(silent=True) or {}
    nome = str(body.get("nome", "")).strip()
    telefone = str(body.get("telefone", "")).strip()
    email = str(body.get("email", "")).strip().lower()
    endereco = str(body.get("endereco", "")).strip()
    senha = str(body.get("senha", "")).strip()

    if len(nome) < 3:
        return error("Informe seu nome completo.")
    if len(only_digits(telefone)) < 10:
        return error("Informe um telefone válido com DDD.")
    if len(senha) < 4:
        return error("A senha deve ter pelo menos 4 caracteres.")

    with get_db() as conn:
        digits = only_digits(telefone)
        existing = conn.execute("SELECT id, telefone, email FROM clientes").fetchall()
        for c in existing:
            if only_digits(c["telefone"]) == digits:
                return error("Já existe uma conta cadastrada com este telefone.", 409)
            if email and (c["email"] or "").lower() == email:
                return error("Já existe uma conta cadastrada com este e-mail.", 409)

        cur = conn.execute(
            "INSERT INTO clientes(nome, telefone, email, endereco, senha_hash) VALUES(?,?,?,?,?)",
            (nome, telefone, email, endereco, generate_password_hash(senha)),
        )
        row = conn.execute("SELECT * FROM clientes WHERE id=?", (cur.lastrowid,)).fetchone()
        session["cliente_id"] = row["id"]
        return jsonify({"cliente": serialize_cliente(row)}), 201


@app.post("/api/cliente/login")
def cliente_login():
    body = request.get_json(silent=True) or {}
    ident = str(body.get("login", "")).strip()
    senha = str(body.get("senha", "")).strip()
    if not ident or not senha:
        return error("Informe seu telefone ou e-mail e a senha.")

    digits = only_digits(ident)
    ident_low = ident.lower()

    with get_db() as conn:
        rows = conn.execute("SELECT * FROM clientes").fetchall()
        matched = None
        for r in rows:
            if (r["email"] and r["email"].lower() == ident_low) or (digits and only_digits(r["telefone"]) == digits):
                matched = r
                break
        if not matched or not check_password_hash(matched["senha_hash"], senha):
            return error("Telefone/e-mail ou senha incorretos.", 401)

        session["cliente_id"] = matched["id"]
        return jsonify({"cliente": serialize_cliente(matched)})


@app.post("/api/cliente/logout")
def cliente_logout():
    session.pop("cliente_id", None)
    return jsonify({"success": True})


@app.get("/api/cliente/me")
def cliente_me():
    cid = session.get("cliente_id")
    if not cid:
        return jsonify({"cliente": None})
    with get_db() as conn:
        row = conn.execute("SELECT * FROM clientes WHERE id=?", (cid,)).fetchone()
        if not row:
            session.pop("cliente_id", None)
            return jsonify({"cliente": None})
        veiculos = conn.execute("SELECT * FROM veiculos WHERE cliente_id=?", (cid,)).fetchall()
        return jsonify({
            "cliente": serialize_cliente(row),
            "veiculos": [serialize_row(conn, "veiculos", v) for v in veiculos],
        })


@app.get("/api/cliente/os")
@require_client
def cliente_list_os():
    cid = session["cliente_id"]
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM ordens_servico WHERE cliente_id=? ORDER BY num DESC", (cid,)
        ).fetchall()
        return jsonify([serialize_os(conn, r) for r in rows])


@app.get("/api/os/consulta/<int:num>")
@require_client
def cliente_find_os(num):
    cid = session["cliente_id"]
    with get_db() as conn:
        row = conn.execute("SELECT * FROM ordens_servico WHERE num=?", (num,)).fetchone()
        if not row:
            return error("Ordem de serviço não encontrada.", 404)
        if row["cliente_id"] != cid:
            return error("Acesso negado: esta ordem de serviço pertence a outro proprietário.", 403)
        return jsonify(serialize_os(conn, row))


@app.post("/api/cliente/os/<int:num>/aprovar")
@require_client
def cliente_approve_os(num):
    cid = session["cliente_id"]
    try:
        with get_db() as conn:
            row = conn.execute("SELECT * FROM ordens_servico WHERE num=?", (num,)).fetchone()
            if not row:
                return error("Ordem de serviço não encontrada.", 404)
            if row["cliente_id"] != cid:
                return error("Acesso negado: somente o proprietário pode aprovar este orçamento.", 403)
            if row["status"] != "Aguardando Aprovação":
                return error("Esta OS não está aguardando aprovação.")

            prev = serialize_os(conn, row)
            aprovado_em = datetime.now().strftime("%d/%m/%Y %H:%M")
            conn.execute(
                "UPDATE ordens_servico SET status='Em Andamento', aprovado_em=? WHERE id=?",
                (aprovado_em, row["id"]),
            )
            new_row = conn.execute("SELECT * FROM ordens_servico WHERE id=?", (row["id"],)).fetchone()
            alerts = sync_stock(conn, prev, serialize_os(conn, new_row))
            final_row = conn.execute("SELECT * FROM ordens_servico WHERE id=?", (row["id"],)).fetchone()
            return jsonify({"record": serialize_os(conn, final_row), "lowAlerts": alerts})
    except ValueError as exc:
        return error(exc)


@app.post("/api/cliente/os/<int:num>/mensagem")
@require_client
def cliente_message_os(num):
    cid = session["cliente_id"]
    body = request.get_json(silent=True) or {}
    obs = str(body.get("obs", "")).strip()
    if not obs:
        return error("Escreva sua dúvida ou solicitação antes de enviar.")
    with get_db() as conn:
        row = conn.execute("SELECT * FROM ordens_servico WHERE num=?", (num,)).fetchone()
        if not row:
            return error("Ordem de serviço não encontrada.", 404)
        if row["cliente_id"] != cid:
            return error("Acesso negado: esta OS pertence a outro proprietário.", 403)
        conn.execute("UPDATE ordens_servico SET obs_cliente=? WHERE id=?", (obs, row["id"]))
        updated = conn.execute("SELECT * FROM ordens_servico WHERE id=?", (row["id"],)).fetchone()
        return jsonify({"record": serialize_os(conn, updated)})


# ==================== AUTENTICAÇÃO DA EQUIPE (ADMIN) ====================

@app.post("/api/admin/login")
def admin_login():
    body = request.get_json(silent=True) or {}
    username = str(body.get("username", "")).strip().lower()
    senha = str(body.get("senha", "")).strip()
    with get_db() as conn:
        user = conn.execute("SELECT * FROM usuarios WHERE username=?", (username,)).fetchone()
        if not user or not check_password_hash(user["senha_hash"], senha):
            return error("Usuário ou senha incorretos.", 401)
        session["staff_role"] = user["role"]
        session["staff_name"] = user["nome"]
        return jsonify({"logged": True, "role": user["role"], "nome": user["nome"]})


@app.post("/api/admin/logout")
def admin_logout():
    session.pop("staff_role", None)
    session.pop("staff_name", None)
    return jsonify({"success": True})


@app.get("/api/admin/me")
def admin_me():
    role = session.get("staff_role")
    if not role:
        return jsonify({"logged": False, "role": None})
    return jsonify({"logged": True, "role": role, "nome": session.get("staff_name")})


# ==================== CRUD REST (EQUIPE + AGENDAMENTO PÚBLICO) ====================

@app.get("/api/<resource>")
@require_staff
def api_list(resource):
    tables = {
        "clientes": "clientes",
        "veiculos": "veiculos",
        "estoque": "estoque",
        "os": "ordens_servico",
        "agenda": "agenda",
    }
    if resource not in tables:
        return error("Recurso inválido.", 404)
    with get_db() as conn:
        rows = conn.execute(f"SELECT * FROM {tables[resource]} ORDER BY id").fetchall()
        data = [serialize_row(conn, resource, row) for row in rows]
        if resource == "estoque" and session.get("staff_role") != "gerente":
            for item in data:
                item.pop("precoCusto", None)
        return jsonify(data)


@app.post("/api/<resource>")
def api_create(resource):
    if resource != "agenda" and not session.get("staff_role"):
        return error("Acesso restrito à equipe.", 401)

    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return error("Envie um objeto JSON válido.")
    try:
        with get_db() as conn:
            alerts = []
            if resource == "clientes":
                nome = str(body["nome"]).strip()
                telefone = str(body["telefone"]).strip()
                if not nome or not telefone:
                    return error("Nome e telefone são obrigatórios.")
                senha = str(body.get("senha") or "1234").strip()
                cur = conn.execute(
                    "INSERT INTO clientes(nome, telefone, email, endereco, senha_hash) VALUES(?,?,?,?,?)",
                    (nome, telefone, body.get("email", ""), body.get("endereco", ""), generate_password_hash(senha)),
                )
            elif resource == "veiculos":
                placa = str(body["placa"]).strip().upper()
                modelo = str(body["modelo"]).strip()
                if not placa or not modelo:
                    return error("Placa e modelo são obrigatórios.")
                cur = conn.execute(
                    "INSERT INTO veiculos(placa, modelo, ano, cliente_id) VALUES(?,?,?,?)",
                    (placa, modelo, body.get("ano") or None, body["clienteId"]),
                )
            elif resource == "estoque":
                peca = str(body["peca"]).strip()
                if not peca:
                    return error("Informe o nome da peça.")
                cur = conn.execute(
                    "INSERT INTO estoque(peca, qtd, minimo, preco_custo, preco) VALUES(?,?,?,?,?)",
                    (
                        peca,
                        int(body.get("qtd", 0)),
                        int(body.get("minimo", 0)),
                        float(body.get("precoCusto", 0)),
                        float(body.get("preco", 0)),
                    ),
                )
            elif resource == "agenda":
                nome = str(body["nome"]).strip()
                telefone = str(body["telefone"]).strip()
                veiculo = str(body["veiculo"]).strip()
                servico = str(body["servico"]).strip()
                data_ag = str(body["data"]).strip()
                horario = str(body.get("horario") or "09:00").strip()
                modalidade = str(body.get("modalidade") or "Na oficina").strip()
                endereco = str(body.get("endereco") or "").strip()

                if not all([nome, telefone, veiculo, servico, data_ag]):
                    return error("Preencha todos os campos obrigatórios do agendamento.")
                if modalidade in ("Serviço em domicílio", "Busca e entrega") and len(endereco) < 5:
                    return error("Informe o endereço completo para atendimento em domicílio ou busca e entrega.")

                slots = get_slots_for_date(conn, data_ag)
                valid_slot = next((s for s in slots if s["hora"] == horario), None)
                if not valid_slot:
                    return error("Horário inválido para o dia selecionado.")
                if not valid_slot["disponivel"]:
                    return error(f"O horário {horario} do dia {data_ag} já está ocupado. Escolha outro.", 409)

                cliente_id = session.get("cliente_id") or body.get("clienteId")
                cur = conn.execute(
                    """INSERT INTO agenda(cliente_id, nome, telefone, veiculo, servico, modalidade, endereco, data, horario, status)
                       VALUES(?,?,?,?,?,?,?,?,?,?)""",
                    (
                        cliente_id,
                        nome,
                        telefone,
                        veiculo,
                        servico,
                        modalidade,
                        endereco,
                        data_ag,
                        horario,
                        body.get("status", "Pendente"),
                    ),
                )
                saved = dict(conn.execute("SELECT * FROM agenda WHERE id=?", (cur.lastrowid,)).fetchone())
                send_webhook(conn, saved)
            elif resource == "os":
                descricao = str(body["descricao"]).strip()
                if not descricao:
                    return error("Informe a descrição do serviço.")
                number = conn.execute("SELECT COALESCE(MAX(num),0)+1 FROM ordens_servico").fetchone()[0]
                cur = conn.execute(
                    """INSERT INTO ordens_servico
                       (num, cliente_id, veiculo_id, km, descricao, modalidade, endereco_atendimento,
                        diagnostico_tecnico, mao_obra, valor, custo_total, pagamento, status, data,
                        obs_cliente, resposta_oficina)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        number,
                        body["clienteId"],
                        body["veiculoId"],
                        body.get("km", 0),
                        descricao,
                        body.get("modalidade", "Na oficina"),
                        body.get("enderecoAtendimento", ""),
                        body.get("diagnosticoTecnico", ""),
                        body.get("maoObra", 0),
                        body.get("valor", 0),
                        body.get("custoTotal", 0),
                        body.get("pagamento", "Pendente"),
                        body.get("status", "Pendente"),
                        body["data"],
                        body.get("obsCliente", ""),
                        body.get("respostaOficina", ""),
                    ),
                )
                for item in body.get("itens", []):
                    conn.execute(
                        """INSERT INTO os_itens(os_id, peca_id, peca, qtd, preco_unit, custo_unit)
                           VALUES(?,?,?,?,?,?)""",
                        (
                            cur.lastrowid,
                            item.get("pecaId"),
                            item["peca"],
                            int(item["qtd"]),
                            float(item["precoUnit"]),
                            float(item.get("custoUnit", 0)),
                        ),
                    )
                row = conn.execute("SELECT * FROM ordens_servico WHERE id=?", (cur.lastrowid,)).fetchone()
                alerts = sync_stock(conn, None, serialize_os(conn, row))
            else:
                return error("Recurso inválido.", 404)

            table = {"os": "ordens_servico"}.get(resource, resource)
            row = conn.execute(f"SELECT * FROM {table} WHERE id=?", (cur.lastrowid,)).fetchone()
            return jsonify({"record": serialize_row(conn, resource, row), "lowAlerts": alerts}), 201
    except KeyError as exc:
        return error(f"Campo obrigatório ausente: {exc.args[0]}")
    except (ValueError, TypeError) as exc:
        return error(exc)
    except sqlite3.IntegrityError as exc:
        return error(f"Violação de integridade: {exc}")


@app.route("/api/<resource>/<int:item_id>", methods=["PUT", "PATCH"])
@require_staff
def api_update(resource, item_id):
    body = request.get_json(silent=True)
    if not isinstance(body, dict):
        return error("Envie um objeto JSON válido.")
    tables = {
        "clientes": "clientes",
        "veiculos": "veiculos",
        "estoque": "estoque",
        "agenda": "agenda",
        "os": "ordens_servico",
    }
    if resource not in tables:
        return error("Recurso inválido.", 404)
    try:
        with get_db() as conn:
            table = tables[resource]
            old = conn.execute(f"SELECT * FROM {table} WHERE id=?", (item_id,)).fetchone()
            if not old:
                return error("Registro não encontrado.", 404)

            if resource == "os":
                previous = serialize_os(conn, old)
                fields = {
                    "clienteId": "cliente_id",
                    "veiculoId": "veiculo_id",
                    "km": "km",
                    "descricao": "descricao",
                    "modalidade": "modalidade",
                    "enderecoAtendimento": "endereco_atendimento",
                    "diagnosticoTecnico": "diagnostico_tecnico",
                    "maoObra": "mao_obra",
                    "valor": "valor",
                    "custoTotal": "custo_total",
                    "pagamento": "pagamento",
                    "status": "status",
                    "data": "data",
                    "aprovadoEm": "aprovado_em",
                    "obsCliente": "obs_cliente",
                    "respostaOficina": "resposta_oficina",
                }
                values = {db: body[key] for key, db in fields.items() if key in body}
                if values:
                    conn.execute(
                        "UPDATE ordens_servico SET "
                        + ", ".join(f"{k}=?" for k in values)
                        + " WHERE id=?",
                        (*values.values(), item_id),
                    )
                if "itens" in body:
                    conn.execute("DELETE FROM os_itens WHERE os_id=?", (item_id,))
                    for item in body["itens"]:
                        conn.execute(
                            """INSERT INTO os_itens(os_id, peca_id, peca, qtd, preco_unit, custo_unit)
                               VALUES(?,?,?,?,?,?)""",
                            (
                                item_id,
                                item.get("pecaId"),
                                item["peca"],
                                int(item["qtd"]),
                                float(item["precoUnit"]),
                                float(item.get("custoUnit", 0)),
                            ),
                        )
                newrow = conn.execute("SELECT * FROM ordens_servico WHERE id=?", (item_id,)).fetchone()
                alerts = sync_stock(conn, previous, serialize_os(conn, newrow))
            else:
                fields = {
                    "clientes": {"nome": "nome", "telefone": "telefone", "email": "email", "endereco": "endereco"},
                    "veiculos": {"placa": "placa", "modelo": "modelo", "ano": "ano", "clienteId": "cliente_id"},
                    "estoque": {"peca": "peca", "qtd": "qtd", "minimo": "minimo", "precoCusto": "preco_custo", "preco": "preco"},
                    "agenda": {
                        "nome": "nome",
                        "telefone": "telefone",
                        "veiculo": "veiculo",
                        "servico": "servico",
                        "modalidade": "modalidade",
                        "endereco": "endereco",
                        "data": "data",
                        "horario": "horario",
                        "status": "status",
                    },
                }[resource]
                values = {db: body[key] for key, db in fields.items() if key in body}
                if resource == "veiculos" and "placa" in values:
                    values["placa"] = values["placa"].upper()
                if resource == "clientes" and body.get("senha"):
                    values["senha_hash"] = generate_password_hash(str(body["senha"]).strip())
                if values:
                    conn.execute(
                        "UPDATE " + table + " SET " + ", ".join(f"{k}=?" for k in values) + " WHERE id=?",
                        (*values.values(), item_id),
                    )
                alerts = []

            row = conn.execute(f"SELECT * FROM {table} WHERE id=?", (item_id,)).fetchone()
            return jsonify({"record": serialize_row(conn, resource, row), "lowAlerts": alerts})
    except (KeyError, ValueError, TypeError) as exc:
        return error(f"Dados inválidos: {exc}")
    except sqlite3.IntegrityError as exc:
        return error(f"Violação de integridade: {exc}")


@app.delete("/api/<resource>/<int:item_id>")
@require_manager
def api_delete(resource, item_id):
    tables = {
        "clientes": "clientes",
        "veiculos": "veiculos",
        "estoque": "estoque",
        "agenda": "agenda",
        "os": "ordens_servico",
    }
    if resource not in tables:
        return error("Recurso inválido.", 404)
    try:
        with get_db() as conn:
            table = tables[resource]
            row = conn.execute(f"SELECT * FROM {table} WHERE id=?", (item_id,)).fetchone()
            if not row:
                return error("Registro não encontrado.", 404)
            if resource == "os":
                previous = serialize_os(conn, row)
                if previous["estoqueBaixado"]:
                    for item in previous["itens"]:
                        stock_change(conn, item, +1)
            conn.execute(f"DELETE FROM {table} WHERE id=?", (item_id,))
            return jsonify({"success": True, "id": item_id})
    except sqlite3.IntegrityError as exc:
        return error(f"Não é possível excluir: existem registros vinculados. {exc}")
    except ValueError as exc:
        return error(exc)


@app.route("/api/config", methods=["GET", "PUT", "POST"])
@require_manager
def api_config():
    with get_db() as conn:
        if request.method == "GET":
            row = conn.execute("SELECT valor FROM config WHERE chave='webhookUrl'").fetchone()
            return jsonify({"webhookUrl": row["valor"] if row else ""})
        body = request.get_json(silent=True) or {}
        url = str(body.get("webhookUrl", "")).strip()
        conn.execute(
            "INSERT INTO config(chave, valor) VALUES('webhookUrl', ?) "
            "ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor",
            (url,),
        )
        return jsonify({"webhookUrl": url})


@app.post("/api/admin/reset")
@require_manager
def api_reset():
    with get_db() as conn:
        conn.executescript("""
            DELETE FROM os_itens;
            DELETE FROM ordens_servico;
            DELETE FROM agenda;
            DELETE FROM veiculos;
            DELETE FROM estoque;
            DELETE FROM clientes;
            DELETE FROM sqlite_sequence;
        """)
    init_db()
    return jsonify({"success": True})


@app.errorhandler(404)
def not_found(_):
    return error("Rota não encontrada.", 404)


init_db()

if __name__ == "__main__":
    app.run(debug=True)