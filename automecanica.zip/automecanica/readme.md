# 🔧 AutoMecânica — Sistema de Gestão de Oficina (Flask + SQLite)

Sistema web completo para gestão de oficina mecânica com **banco de dados relacional SQLite (`oficina.db`)**, **autenticação de clientes e equipe**, **agendamento com controle de horários**, **atendimento em domicílio / busca e entrega**, **aprovação online de orçamentos** e **suíte de testes automatizados**.

---

## 📁 Estrutura de Pastas

Ao levar o projeto para outro computador, **não copie a pasta `venv`** (ela contém caminhos da máquina original). Leve apenas:

```text
automecanica/
├── app.py              # Backend Flask, API REST, regras de negócio e SQLite
├── test_app.py         # Testes unitários e de integração
├── requirements.txt    # Dependências (Flask)
├── iniciar.bat         # Atalho de 1 clique para Windows (opcional)
├── oficina.db          # Banco SQLite (criado automaticamente se não existir)
└── templates/
    └── index.html      # Interface completa (Site Público, Área do Cliente e Admin)
```

---

## 🚀 Como Executar no Windows

### Opção 1: Via Terminal (PowerShell ou CMD) — Recomendado
Abra o terminal dentro da pasta `automecanica` e execute:

```powershell
python -m venv venv
.\venv\Scripts\python.exe -m pip install -r requirements.txt
.\venv\Scripts\python.exe app.py
```

Acesse no navegador: **`http://127.0.0.1:5000`**

> **Nota:** Chamar `.\venv\Scripts\python.exe` diretamente evita o erro de bloqueio de scripts (`ExecutionPolicy`) do PowerShell. Caso queira ativar o ambiente manualmente, rode antes:
> `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` e depois `.\venv\Scripts\Activate.ps1`.

---

### Opção 2: Arquivo de Clique Único (`iniciar.bat`)
Crie um arquivo `iniciar.bat` na raiz da pasta `automecanica` com o conteúdo abaixo e dê **dois cliques** na hora da apresentação:

```bat
@echo off
if not exist venv (
    python -m venv venv
)
.\venv\Scripts\python.exe -m pip install -r requirements.txt
start http://127.0.0.1:5000
.\venv\Scripts\python.exe app.py
pause
```

---

### Opção 3: Apresentar em outro PC pela mesma rede Wi-Fi (sem instalar nada no PC da sala)
1. Conecte seu notebook e o PC da apresentação na mesma rede Wi-Fi (pode ser o roteador do celular).
2. Na última linha do `app.py`, troque `app.run(debug=True)` por:
   ```python
   app.run(host="0.0.0.0", port=5000, debug=True)
   ```
3. Rode `python app.py` no seu notebook e acesse no navegador do outro computador o IP exibido no terminal (ex.: `http://192.168.x.x:5000`).

---

## 🧪 Como Rodar os Testes (Unitários e Integração)

Com o terminal na pasta `automecanica`, execute:

```powershell
.\venv\Scripts\python.exe -m unittest -v test_app.py
```

**O que é validado nos testes:**
1. `test_unit_password_hashing`: Criptografia e verificação de hash de senha (`werkzeug.security`).
2. `test_unit_stock_deduction_and_refund`: Baixa automática de peças ao iniciar OS, alerta de estoque mínimo e estorno ao cancelar.
3. `test_unit_slots_weekday_vs_sunday`: Bloqueio automático de horários aos domingos.
4. `test_integration_client_security_and_budget_approval`: Garante que apenas o cliente proprietário consulta (`403 Forbidden` para terceiros) e aprova seu próprio orçamento (`200 OK`).
5. `test_integration_scheduling_slot_conflict_and_home_service`: Valida agendamento em domicílio e bloqueio de choque de horário (`409 Conflict`).
6. `test_integration_staff_rbac_permissions`: Garante que o mecânico não exclui clientes nem acessa configurações restritas ao gerente (`403 Forbidden`).

---

## 🔑 Credenciais de Demonstração (Cola Rápida)

### Área do Cliente (Site Público → "Área do Cliente")
| Cliente | Login | Senha | Cenário pronto para demonstrar |
| :--- | :--- | :--- | :--- |
| **Mariana Souza** | `mariana@email.com` | `1234` | Possui **OS #0008** (`Aguardando Aprovação`) com **Busca e entrega** pronta para aprovar ao vivo. |
| **Carlos Silva** | `carlos@email.com` | `1234` | Possui **OS #0007** (`Em Andamento`) e histórico de atendimento em domicílio. |

### Painel Administrativo (Menu → "Área admin" ou `#admin`)
| Perfil | Usuário | Senha | Permissões |
| :--- | :--- | :--- | :--- |
| **Gerente** | `admin` | `1234` | Acesso total: faturamento, lucro líquido, exclusões, clientes, estoque e webhook. |
| **Mecânico** | `mecanico` | `1234` | Foco técnico: ordens de serviço, parecer técnico, veículos, agenda e estoque (sem valores financeiros). |

---

## 🎯 Roteiro Rápido de Demonstração (5 Passos)

1. **Agendamento Inteligente + Modalidades:**
   * Role até **Agende seu atendimento**, escolha a data de hoje e mostre que o horário `10:00` já aparece **Ocupado** (reservado pelo Paulo Lima).
   * Selecione **Serviço em domicílio** ou **Busca e entrega** para mostrar o campo dinâmico de endereço e finalize um agendamento.
2. **Segurança e Privacidade do Proprietário:**
   * Vá para **Área do Cliente**, entre com `carlos@email.com` (`1234`) e mostre que ele só enxerga as próprias OS (não tem acesso à OS #0008 da Mariana).
   * Saia e entre com `mariana@email.com` (`1234`).
3. **Aprovação Online e Comunicação Direta:**
   * Na conta da Mariana, abra a **OS #0008**, envie uma dúvida no campo **"Enviar Dúvida / Revisão"** e clique em **Aprovar Orçamento**.
   * Mostre que o status muda na hora para **Em Andamento** e fica registrado no SQLite (mesmo dando `F5`).
4. **Visão do Mecânico vs. Gerente (`#admin`):**
   * Entre como `mecanico` (`1234`): mostre a lista limpa de serviços, o parecer técnico e a ausência de dados financeiros.
   * Entre como `admin` (`1234`): mostre que a aprovação da Mariana já deu baixa automática nas peças do estoque e atualizou os indicadores.
5. **Execução dos Testes Automatizados:**
   * Abra o terminal e rode `.\venv\Scripts\python.exe -m unittest -v test_app.py` para mostrar os 6 testes passando (`OK`).

---

## 🛠️ Solução Rápida de Problemas

* **`TemplateNotFound: index.html`:** Verifique se o HTML está dentro da subpasta `templates/index.html` e não solto na raiz junto com o `app.py`.
* **Porta 5000 ocupada:** Feche outros terminais abertos com Python rodando ou finalize pelo Gerenciador de Tarefas.